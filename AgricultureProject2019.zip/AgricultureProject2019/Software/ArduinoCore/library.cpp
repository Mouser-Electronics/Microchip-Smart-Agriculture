/*
 * ArduinoCore.cpp
 *
 * Created: 2/16/2019 8:37:50 PM
 * Author : mpark
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

