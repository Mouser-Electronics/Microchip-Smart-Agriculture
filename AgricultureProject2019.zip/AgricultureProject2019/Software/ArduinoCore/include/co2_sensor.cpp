#include "co2_sensor.h"

co2_sensor::co2_sensor() {
}


boolean co2_sensor::begin(int co2pin) {
  co2analogPin = co2pin;
  pinMode(co2analogPin, INPUT);
  return true;
}


float co2_sensor::readCO2level() {
  float voltageDiference = 0.0;
  float concentration = 0.0;
  float voltage = 0.0;
  
  int adcVal = analogRead(co2analogPin);
  voltage = adcVal*(3300/1024.0);

  if(voltage == 0.0) {
    Serial.println("A problem has occurred with the sensor.");
  }
  else if(voltage < 400) {
    Serial.println("Pre-heating the sensor...");
  }
  else {
    float voltageDiference=voltage-400;
    float concentration=(voltageDiference*50.0)/16.0;

    Serial.print("voltage:");
    Serial.print(voltage);
    Serial.println("mv");
    Serial.print(concentration);
    Serial.println("ppm");
    
    return concentration;
  }

  delay(2000);
  
  return concentration;

}
