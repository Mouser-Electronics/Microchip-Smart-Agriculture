char myssid[] = "YOURSSIDHERE";
char myssidpw[] = "YOURSSIDKEYHERE";

char server[] = "mqtt.mediumone.com";
int port = 61619;
char pub_topic[]="0/Z0TDLxUZ5Mg/Y-Wg1li8sl8/02017201/ ";
char sub_topic[]="1/M1PROJECTID/M1USERID/mkr1010/event";
char mqtt_username[]="M1PROJECTID/M1USERID";
char mqtt_password[]="APIKEY/M1USERIDPASSWORD";


char devAddr[] = "02017201";
char nwkSKey[] = "AE17E567AECC8787F749A62F5541D522";
char appSKey[] = "8D7FFEF938589D95AAD928C2E2E7E48F";