/*
 *
 * CHECK THE RULES BEFORE USING THIS PROGRAM!
 *
 * CHANGE ADDRESS!
 * Change the device address, network (session) key, and app (session) key to the values
 * that are registered via the TTN dashboard.
 * The appropriate line is "myLora.initABP(XXX);" or "myLora.initOTAA(XXX);"
 * When using ABP, it is advised to enable "relax frame count".
 *
 * Connect the RN2xx3 as follows:
 * Uart TX -- 3
 * Uart RX -- 2
 * Reset -- 14
 * Vcc -- 3.3V
 * Gnd -- Gnd
 *
 * If you use a device with a free hardware serial port, you can replace
 * the line "rn2xx3 myLora(mySerial);"
 * with     "rn2xx3 myLora(SerialX);"
 * where the parameter is the serial port the RN2xx3 is connected to.
 * Remember that the serial port should be initialised before calling initTTN().
 * For best performance the serial port should be set to 57600 baud, which is impossible with a software serial port.
 * If you use 57600 baud, you can remove the line "myLora.autobaud();".
 *
 */
#include <rn2xx3.h>
#include <SoftwareSerial.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
#include <Adafruit_seesaw.h>
#include <co2_sensor.h>
#include <secretstuff.h>
#include <Arduino.h>

void initialize_radio();
void callback(char* topic, byte* payload, unsigned int length);
void sensor_loop();
void heartbeat_loop();
float getPHlevel();


SoftwareSerial mySerial(2, 3); // RX, TX
Adafruit_BME280 bme;
Adafruit_seesaw soilSensor;
co2_sensor co2sensor;

//create an instance of the rn2xx3 library,
//giving the software serial as port to use
rn2xx3 myLora(mySerial);

//Control variables for MQTT connection to MediumOne servers
static int heartbeat_timer = 0;
static int sensor_timer = 0;
static int heartbeat_period = 60000;
long lastReconnectAttempt = 0;

//Local control variables
static int sensor_period = 5000;
const float vref = 3.3;
const float phOffset = 0.0;

//Declare variables for pins
const int phSensorPin = A0;
const int co2SensorPin = A1;

// the setup routine runs once when you press reset:
void setup()
{

  // Open serial communications and wait for port to open:
  Serial.begin(57600); //serial port to computer
  mySerial.begin(9600); //serial port to radio
  
  Serial.println("Initializing hardware settings...");
  
  initialize_radio();

  //transmit a startup message
  myLora.tx("TTN Mapper on TTN Enschede node");

    
  //Initialize BME280 Temp/Hum/Pres sensor
  Serial.println("Connecting to BME280 sensor...");
  if (!bme.begin()) {
    Serial.println("Could not find a valid BME280 sensor, check wiring!");
    while (1);
  }
  Serial.println("Successfully connected to BME280 sensor!");
  
  

  Serial.println("Connecting to CO2 sensor...");
  if (!co2sensor.begin(co2SensorPin)) {
    Serial.println("Could not find a valid CO2 sensor, check wiring!");
    while (1);
  }
  
  Serial.println("Successfully connected to CO2 sensor!");

  
  
  /*Serial.println("Connecting to soil sensor...");
  if (!soilSensor.begin(0x36)) {
    Serial.println("ERROR! Soil sensor not found");
    while (1);
  } else {
    Serial.print("Soil sensor started! version: ");
    Serial.println(soilSensor.getVersion(), HEX);
  }*/

  
  
  pinMode(phSensorPin, INPUT);
  
  
  


  
  
  Serial.println("Setup is complete!");

}

void initialize_radio()
{
  //reset rn2xx3
  pinMode(14, OUTPUT);
  digitalWrite(14, LOW);
  delay(500);
  digitalWrite(14, HIGH);

  delay(100); //wait for the RN2xx3's startup message
  mySerial.flush();

  //Autobaud the rn2xx3 module to 9600. The default would otherwise be 57600.
  myLora.autobaud();

  //check communication with radio
  String hweui = myLora.hweui();
  while(hweui.length() != 16)
  {
    Serial.println("Communication with RN2xx3 unsuccessful. Power cycle the board.");
    Serial.println(hweui);
    delay(10000);
    hweui = myLora.hweui();
  }

  //print out the HWEUI so that we can register it via ttnctl
  Serial.println("When using OTAA, register this DevEUI: ");
  Serial.println(myLora.hweui());
  Serial.println("RN2xx3 firmware version:");
  Serial.println(myLora.sysver());

  //configure your keys and join the network
  Serial.println("Trying to join TTN");
  bool join_result = false;


  /*
   * ABP: initABP(String addr, String AppSKey, String NwkSKey);
   * Paste the example code from the TTN console here:
   */
 
  const char *devAddr = "02017201";
  const char *nwkSKey = "AE17E567AECC8787F749A62F5541D522";
  const char *appSKey = "8D7FFEF938589D95AAD928C2E2E7E48F";

  join_result = myLora.initABP(devAddr, appSKey, nwkSKey);

  /*
   * OTAA: initOTAA(String AppEUI, String AppKey);
   * If you are using OTAA, paste the example code from the TTN console here:
   */
  //const char *appEui = "70B3D57ED0023173";
  //const char *appKey = "CC194065031E5FCE5BCD16EA38A467EB";

  //join_result = myLora.initOTAA(appEui, appKey);


  while(!join_result)
  {
    Serial.println("Unable to join. Are your keys correct, and do you have TTN coverage?");
    delay(60000); //delay a minute before retry
    join_result = myLora.init();
  }
  Serial.println("Successfully joined TTN");

}

void callback(char* topic, byte* payload, unsigned int length) {
  // handle message arrived
  int i = 0;
  char message_buff[length + 1];
  for (i = 0; i < length; i++) {
    message_buff[i] = payload[i];
  }
  message_buff[i] = '\0';

  Serial.print(F("Received some data: "));
  Serial.println(String(message_buff));
}

void sensor_loop() {
  float humidity = 0.0;
  float tempC = 0.0;
  float moistureLevel = 0.0;
  float phLevel = 0.0;
  float co2Level = 0.0;


  if ((millis() - sensor_timer) > sensor_period) {
    sensor_timer = millis();
    //tempC = bme.readTemperature();
    //humidity = bme.readHumidity();
    //moistureLevel = soilSensor.touchRead(0);
    phLevel = getPHlevel();
    co2Level = co2sensor.readCO2level();

    String payload = (char *) pub_topic;
    payload += "{\"event_data\":{\"temperature\":";
    payload += tempC;
    payload += ",\"humidity\":";
    payload += humidity;
    payload += ",\"moisture\":";
    payload += moistureLevel;
    payload += ",\"ph\":";
    payload += phLevel;
    payload += ",\"co2\":";
    payload += co2Level;
    payload += "}}";
    
    //String base16decode (payload);
    Serial.println(payload);
    myLora.base16decode(payload);
    myLora.txUncnf(payload);
    Serial.println(myLora.getRx());

    /*if (client.loop()) {
      Serial.print(F("Sending sensor: "));
      Serial.println(payload);

      if (client.publish((char *) pub_topic, (char*) payload.c_str()) ) {
        Serial.println("Publish ok");
      } else {
        Serial.print(F("Failed to publish sensor data: "));
        Serial.println(String(client.state()));
      }
    }*/

    Serial.println();
    delay(2000);
  }
}


/*****************************************************
   Function: heartbeat_loop
   Inputs: None
   Return: None
   Description:  Initializes serial communications,
   sensor I2C comms, and I/O mode of pins
 *****************************************************/
void heartbeat_loop() {
  if ((millis() - heartbeat_timer) > heartbeat_period) {
    heartbeat_timer = millis();
    String payload = (char *) pub_topic;
    payload += "{\"event_data\":{\"millis\":";
    payload += millis();
    payload += ",\"heartbeat\":true}}";
    
    Serial.println(payload);
    myLora.base16decode(payload);
    myLora.tx(payload);
    Serial.println(myLora.getRx());

    /*if (client.loop()) {
      Serial.print(F("Sending heartbeat: "));
      Serial.println(payload);

      if (client.publish((char *) pub_topic, (char*) payload.c_str()) ) {
        Serial.println(F("Publish ok"));
      } else {
        Serial.print(F("Failed to publish heartbeat: "));
        Serial.println(String(client.state()));
      }
    }*/
  }
}





/*****************************************************
   Function: getPHreading
   Inputs: None
   Return: None
   Description:  
 *****************************************************/
float getPHlevel() {
  float phAnalogReading = analogRead(phSensorPin) * vref / 1024.0;
  float phLevel = 3.5 * phAnalogReading + phOffset;
  return phLevel;
}

// the loop routine runs over and over again forever:
void loop()
{
    
    Serial.println("TXing");
    heartbeat_loop();
    sensor_loop();
    Serial.println(myLora.getRx());
  

}


